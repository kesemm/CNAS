How to use FTPSync in branding mode

1. Copy FTPSync.license and FTPSync.bmp file to the directory where FTPSync.exe is located.
2. Add the following lines to your .INI file (see demo4-branding.ini for example):

[Branding]
Image=FTPSync.bmp
ToolName=FileSync

Run FTPSync. It should run in branding mode. You can now modify BMP file as you wish (your logo, 
company data, etc.), change ToolName as you wish or even use your own icon. See Branding 
section in documentation for details.

When FTPSync brandable license is purchased, you will receive a new FTPSync.license file, where
[EVALUATION] will be replaced with your company name.
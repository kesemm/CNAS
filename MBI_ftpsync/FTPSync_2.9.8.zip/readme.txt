FTPSync Documentation is now available on-line at:
  http://www.cyberkiko.com/Docs/FTPSync29